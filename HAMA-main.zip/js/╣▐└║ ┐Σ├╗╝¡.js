const postList = document.getElementById("postList");
const posts = [
  { nickname: "옥동 장미칼"
,   content: "이 녀석들 내 성격 까먹었나보네."
,   image: "image1.jpg" },
  { nickname: "경"
,   content: "좋았숴."
,   image: "image2.jpg" },
  { nickname: "영"
,   content: "영촤 ~"
,   image: "image3.jpg" },
];

// 가상의 주소와 날짜 데이터
const userAddress = "서울시 강남구";
const userDate = "2023-08-24";

function fetchPosts() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(posts);
    }, 1000);
  });
}

async function displayPosts() {
    const fetchedPosts = await fetchPosts();

    fetchedPosts.forEach((post) => {
      const postItem = document.createElement("li");
      postItem.classList.add("post");
      postItem.innerHTML = `<img src="${post.image}" alt="프로필 사진">
      <div class="post-content">
        <h3>닉네임: ${post.nickname}</h3>
        <p class="post-text">내용: ${post.content}</p>
        <div class="user-info">
          <p>위치: ${userAddress}</p>
          <p>희망일: ${userDate}</p>
        </div>
      </div>
      <div class="buttons">
        <button class="button colorbutton">견적서 작성</button>
        <button class="button borderbutton">삭제하기</button>
      </div>`;
    postList.appendChild(postItem);
  });
}
displayPosts();
