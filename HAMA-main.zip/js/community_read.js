

document.addEventListener("DOMContentLoaded", function () {
    // 현재 날짜와 시간을 가져오는 Date 객체 생성
    const currentDate = new Date();

    // 년, 월, 일, 시, 분을 가져옵니다
    const year = currentDate.getFullYear();
    const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
    const day = currentDate.getDate().toString().padStart(2, '0');
    const hours = currentDate.getHours().toString().padStart(2, '0');
    const minutes = currentDate.getMinutes().toString().padStart(2, '0');

    // 날짜를 원하는 형식으로 포맷팅 (예: "년-월-일 시간:분")
    const formattedDate = `${year}-${month}-${day} ${hours}:${minutes}`;

    // 게시글 내용을 담은 배열 생성
    const content_profile = [
        {
            writerPhoto: "../img/루루팡.png",
            writerNick: "월급루루팡루루피",
            uploadDate: formattedDate, // 자동으로 생성된 날짜
            viewCount: 100, // 조회수
        }
    ];
    const content_text = [
        {
            title: "글제목",
            content: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur exercitationem odit delectus quod, excepturi qui eum architecto totam rem facere nostrum deserunt, sunt, similique corrupti nihil fugiat nulla maiores. Assumenda.
                    Exercitationem odit omnis dicta commodi quo officia cupiditate fugiat unde saepe, ipsam, at nulla repellendus? Quia quod eaque soluta et tempora assumenda maiores error, harum nesciunt nostrum dolore blanditiis modi.
                    Veniam deleniti dignissimos numquam praesentium ut voluptatibus fugiat alias dolorem deserunt earum odit sit tenetur atque rem fugit suscipit soluta molestias, quidem, facere autem! Libero quibusdam hic cum sapiente veritatis.
                    Ratione error est eum sint reiciendis animi ad fuga ullam nihil sed voluptas doloremque dolor architecto, similique, earum enim ipsa cumque, repellat mollitia ut. Iusto dolores voluptate vero ex aliquam?
                    Vitae amet est delectus molestias, iste deleniti perspiciatis illum. Exercitationem illo libero, sit architecto reprehenderit facilis totam incidunt laudantium, nobis mollitia magnam dolores velit quam saepe fugit sint doloribus impedit.`, // 게시글 내용 HTML 또는 텍스트
        }
    ];
    const read_comment = [
        {
            userNick: "스탠리킴",
            userCmtTime: formattedDate, // 자동으로 생성된 날짜
            userCmt: "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis voluptatum nobis alias blanditiis aliquam! Reiciendis quae quisquam laborum inventore! Eius amet voluptate quis eos recusandae nulla veniam, blanditiis quae maxime."
        },
        // 댓글 추가될 경우 사용할 공간
    ];
    const comment_writeBox = [
        {
            myNick: "사용자 닉네임",
        }
    ]

    // 게시글을 동적으로 생성하고 내용을 변경하는 함수
    function createPostsHTML(profile, text, comments) {
        let html = '';

        for (let i = 0; i < profile.length; i++) {
            const postHTML = `
            <div class="read_prf_txt_rpl">
                    <div class="read_content">
                        <div class="content_title">${text[i].title}</div>
                        <div class="content_profile">
                            <div class="profile_1 writerPhoto">
                                <img src="${profile[i].writerPhoto}" alt="작성자사진">
                            </div>
                            <div class="profile_2 writerInfo">
                                <div class="writerNick">${profile[i].writerNick}</div>
                                <div class="upLoad_Cnt">
                                    <span class="uploadDate">${profile[i].uploadDate}</span>
                                    <div class="viewCnt">
                                        <i class="fa-solid fa-eye" style="color: #cccccc;"></i>
                                        <span>${profile[i].viewCount}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="profile_3 menu">
                                <button class="wrapMenuBtn"><i class="fa-solid fa-ellipsis"></i></button> 
                                <div class="wrapMenu">
                                    <button id="modifyBtn">수정하기</button>
                                      <span id="wrapMenuBar">|</span>
                                    <button id="deleteBtn">삭제하기</button>
                                </div>
                            </div>
                        </div>
                        <div class="content_text">${text[i].content}</div>
                    </div>
                    <div class="read_comment">
                        <div class="comment_bar">
                            <div><i class="fa-solid fa-comments" style="color: #cccccc;"></i> 댓글 
                                <span id="cmtCnt">${comments.length}</span>
                            </div>
                        </div>
                        <div class="comment_userItem">
                            <div class="userItem_2 nick_time_cmt">
                                <div class="user_nick_time">
                                    <span id="userNick">${comments[i].userNick}</span>
                                    <div id="userCmtTime">${comments[i].userCmtTime}</div>
                                </div>
                                <div id="userCmt">${comments[i].userCmt}</div>
                            </div>
                            <div class="userItem_3 chatBtn">
                                <a href="test.html"><div id="chatBtn">채팅하기</div></a>
                            </div>
                        </div>
                        <div id="comment_section"> 신규댓글
                        </div>
                        <div class="comment_writeBox">
                            <div class="writeBox2">
                                <div id="myNick">${comment_writeBox[i].myNick}</div>
                                <textarea id="textInput" placeholder="댓글을 입력해주세요" required></textarea>
                            </div>
                            <div class="writeBox3">
                                <button id="sendBtn"><i class="fa-solid fa-paper-plane"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
        `;

            html += postHTML;
        }
        return html;
    }

    // 게시글을 화면에 추가
    const contentContainer = document.querySelector('.read_prf_txt_rpl');
    contentContainer.innerHTML = createPostsHTML(content_profile, content_text, read_comment);

    // 댓글 js 구현
    // 전송 버튼 클릭 이벤트 핸들러
    document.addEventListener("DOMContentLoaded", function () {
        const textInput = document.getElementById("textInput");
        const sendBtn = document.getElementById("sendBtn");
        const commentsList = document.getElementById("comments");

        sendBtn.addEventListener("click", function () {
            const commentText = textInput.value;
            if (myText.trim() === "") {
                // 댓글을 입력하지 않은 경우 알림 표시
                alert("댓글을 입력하세요");
            } else {
                const commentElement = document.createElement("div");
                commentElement.className = "comment";
                commentElement.textContent = commentText;
                commentsList.appendChild(commentElement);
                textInput.value = "";
            }
        });
    });



});

