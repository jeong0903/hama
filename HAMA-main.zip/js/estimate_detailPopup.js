
// showDetailPopupWithData 함수 정의
function showDetailPopupWithData(index) {

  // 클릭된 버튼에 따라 데이터를 가져옵니다. 여기서는 하나의 예시 데이터를 사용합니다.
        const detailContents = [
          {
            detail_cate1: "기타",
            detail_cate2: "서류작업",
            detail_pay: "200,000",
            detail_description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem a, nostrum cupiditate nemo totam consectetur qui quas neque impedit fuga repellat aperiam ullam nulla repudiandae veniam. Quod totam vitae voluptates."
          },
          // 다른 데이터 항목들을 필요에 따라 추가할 수 있습니다.
        ]

    };
  