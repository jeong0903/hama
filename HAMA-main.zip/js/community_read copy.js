/* 마우스 클릭에 따라 메뉴버튼 css 변화 */
document.addEventListener("DOMContentLoaded", function () {
    const wrapMenuBtn = document.getElementById("wrapMenuBtn");
    const wrapMenu = document.getElementById("wrapMenu");

    wrapMenu.style.display = "none"; // 초기에 숨겨진 상태로 설정

    wrapMenuBtn.addEventListener("click", function () {
        if (wrapMenu.style.display === "none") {
            wrapMenu.style.display = "block"; // 버튼을 누르면 보이게 설정
            wrapMenuBtn.style.color = "#0056b3"; // 배경 색상을 변경
        } else {
            wrapMenu.style.display = "none"; // 다시 버튼을 누르면 숨김
            wrapMenuBtn.style.color = "#00B0FA";
        }
    });
});

/* 글제목, 작성자 정보, 게시글 본문 */
// 게시글 정보 객체 생성 (실제 데이터로 대체해야 합니다)
const postInfo = {
    title: "글제목",
    writerPhoto: "img/루루팡.png",
    writerNick: "월급루루팡루루피",
    uploadDate: "업로드 날짜",
    viewCount: 100, // 조회수
    content: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur exercitationem odit delectus quod, excepturi qui eum architecto totam rem facere nostrum deserunt, sunt, similique corrupti nihil fugiat nulla maiores. Assumenda.
                    Exercitationem odit omnis dicta commodi quo officia cupiditate fugiat unde saepe, ipsam, at nulla repellendus? Quia quod eaque soluta et tempora assumenda maiores error, harum nesciunt nostrum dolore blanditiis modi.
                    Veniam deleniti dignissimos numquam praesentium ut voluptatibus fugiat alias dolorem deserunt earum odit sit tenetur atque rem fugit suscipit soluta molestias, quidem, facere autem! Libero quibusdam hic cum sapiente veritatis.
                    Ratione error est eum sint reiciendis animi ad fuga ullam nihil sed voluptas doloremque dolor architecto, similique, earum enim ipsa cumque, repellat mollitia ut. Iusto dolores voluptate vero ex aliquam?
                    Vitae amet est delectus molestias, iste deleniti perspiciatis illum. Exercitationem illo libero, sit architecto reprehenderit facilis totam incidunt laudantium, nobis mollitia magnam dolores velit quam saepe fugit sint doloribus impedit.`, // 게시글 내용 HTML 또는 텍스트
};

// 게시글 정보를 화면에 렌더링하는 함수
function renderPostInfo() {
    // 게시글 정보를 화면에 출력
    document.querySelector(".content_title").textContent = postInfo.title;
    document.querySelector(".writerPhoto").textContent = postInfo.writerPhoto;
    document.querySelector(".writerNick").textContent = postInfo.writerNick;
    document.querySelector("#uploadDate").textContent = postInfo.uploadDate;
    document.querySelector("#viewCnt").textContent = `(${postInfo.viewCount} 조회수)`;

    // 게시글 내용을 삽입
    document.querySelector(".content_text").innerHTML = postInfo.content;
}

// 댓글 정보 객체 생성 (실제 데이터로 대체해야 합니다)
const commentInfo = {
    userPhoto: "댓글 작성자 사진 URL",
    userNick: "댓글 작성자 닉네임",
    commentDate: "댓글 작성 날짜",
    commentText: "댓글 내용 Lorem ipsum dolor sit amet...",
};

// 댓글 정보를 화면에 렌더링하는 함수
function renderComment() {
    // 댓글 정보를 화면에 출력
    const commentContainer = document.querySelector(".comment_userItem");
    const commentHtml = `
        <div class="userItem_1 userPhoto">${commentInfo.userPhoto}</div>
        <div class="userItem_2 nick_time_cmt">
            <div class="user_nick_time">
                <span id="userNick">${commentInfo.userNick}</span>
                <div id="userCmtTime">${commentInfo.commentDate}</div>
            </div>
            <div id="userCmt">${commentInfo.commentText}</div>
        </div>
        <div class="userItem_3 chatBtn">
            <a href="test.html"><div id="chatBtn">채팅하기</div></a>
        </div>
    `;
    commentContainer.innerHTML = commentHtml;
}

// 페이지 로드 시 게시글과 댓글 정보를 화면에 렌더링
window.addEventListener("DOMContentLoaded", function () {
    renderPostInfo();
    renderComment();
});

